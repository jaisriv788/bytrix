import SavingBox from "../components/saving/SavingBox";
import Faq from "../components/saving/Faq";

function Saving() {
  return (
    <>
      <SavingBox />
      <Faq />
    </>
  );
}

export default Saving;
